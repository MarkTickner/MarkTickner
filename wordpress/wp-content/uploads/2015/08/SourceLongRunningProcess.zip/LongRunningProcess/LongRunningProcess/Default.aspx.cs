﻿using System.Web.UI;

namespace LongRunningProcess
{
    public partial class Default : Page
    {
    }
}